<?php
include_once 'conexao.php';

      if (isset($_GET['id_form'])) {
        $id_form=$_GET['id_form'];
        $sql = "SELECT * FROM form WHERE id_form = '$id_form'";
        $result=mysqli_query($conn,$sql);

        $row = mysqli_fetch_assoc($result);

        $up_nome = $row['nome'];
        $up_email = $row['email'];
        $up_telefone = $row['telefone'];
        $up_endereco = $row['endereco'];
        $up_bairro = $row['bairro'];
        $up_nascimento = $row['nascimento'];
 
 
        //var_dump($row);  
    }
   
    if (isset($_POST['btn_atualizar'])){
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'];
        $endereco = $_POST['endereco'];
        $bairro = $_POST['bairro'];
        $nascimentio = $_POST['nascimento'];

        $sql = "UPDATE form SET nome = '$nome', email='$email', telefone='$telefone' , endereco='$endereco' , bairro = '$bairro' , nascimento = '$nascimentio' WHERE id_form = '$id_form'";
        $result = mysqli_query($conn, $sql);

        if ($result){ 
            echo '<script>';
            echo 'alert("Atualizado com sucesso");';
            echo '</script>';
        } 

    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
<link rel="stylesheet" href="style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
<body>
  <nav class="navbar navbar-light" style="background-color: blue">
    <a class="navbar-brand" href="#">
      <img src="img/tiger (1).png" width="110" height="80"  alt="">
    </a>
  </nav>
  <form method="POST">
  <form class="p-3">       
  <div class= "my-3">
  <label class="form-label">Nome:</label>
  <input class="form-control" type="text" name="nome" value="<?php echo $up_nome ?>"/>
  </div>

  <form class="p-3">       
    <div class= "my-3">
    <label class="form-label">Email:</label>
    <input class="form-control" type="text" name="email" value="<?php echo $up_email ?>"/>
    </div>

    <form class="p-3">       
      <div class= "my-3">
      <label class="form-label">telefone:</label>
      <input class="form-control" type="text" name="telefone" value="<?php echo $up_telefone ?>"/>
      </div>
    
      <form class="p-3">       
        <div class= "my-3">
        <label class="form-label">endereco:</label>
        <input class="form-control" type="text" name="endereco" value="<?php echo $up_endereco ?>"/>
        </div>
      
      <form class="p-3">       
        <div class= "my-3">
        <label class="form-label">Bairro:</label>
        <input class="form-control" type="text" name="bairro" value="<?php echo $up_bairro ?>"/>
        </div>


        <form class="p-3">       
          <div class= "my-3">
          <label class="form-label">nascimento:</label>
          <input class="form-control" type="text" name="nascimento" value="<?php echo $up_nascimento ?>"/>
          </div>
      
  
        <div class="my-1">
              <input class="btn-primary" type="submit" name="btn_atualizar" value="Atualizar"/>
        </div>
      </form>

  </body>
  </html>
    